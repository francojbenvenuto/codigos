#include <stdio.h>
#include "funciones_estudiante.h"
#include "constantes.h"
/*
    No modificar este archivo.
    Todas las modificaciones deben estar en funciones_estudiante.c y funciones_estudiante.h
*/
int main(int argc, char* argv[])
{
    return solucion(argc, argv);
}
