#include <iostream>
using namespace std;

int main()
{
  int v[10];

  for (int i = 0; i< 10; i++)
  {
    v[i]= i;
  }
 cout << "hola" << endl;
  cout << "hola" << endl;
   cout << "hola" << endl;
    cout << "hola" << endl;
  cout << "hola" << endl;
   cout << "hola" << endl;
   
   cout << "hola" << endl;
   

   return 0;
}