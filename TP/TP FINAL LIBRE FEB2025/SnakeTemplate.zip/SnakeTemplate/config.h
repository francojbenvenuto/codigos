#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

#define IMG_HEAD "./sprites/snake_green_head_32.bmp"
#define IMG_BODY "./sprites/snake_green_blob_32.bmp"

//Modificable segun tam de la pantalla y tam de otros elementos,
//
#define SCREEN_ORDER 600

#endif // CONFIG_H_INCLUDED
