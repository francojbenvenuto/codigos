#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#ifdef __MINGW32__
    #define SDL_MAIN_HANDLED
    #include <SDL_main.h>
#endif
#include <SDL.h>
#include "config.h"



/**
Pablo Soligo. Plantilla de proyecto codeblocks para juego snake (Linux/Windows).
*/

void SetColor(SDL_Renderer *renderer, SDL_Color color) {
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
}

SDL_Texture* loadTexture(const char *path, SDL_Renderer *renderer) {
    SDL_Surface *loadedSurface = SDL_LoadBMP(path); // Carga una imagen BMP
    if (!loadedSurface) {
        printf("Error al cargar la imagen: %s\n", SDL_GetError());
        return NULL;
    }

    // Convierte la superficie en una textura
    SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, loadedSurface);
    SDL_FreeSurface(loadedSurface); // Libera la superficie temporal

    if (!texture) {
        printf("Error al crear textura: %s\n", SDL_GetError());
    }
    return texture;
}

void drawFilledCircle(SDL_Renderer* renderer, int cx, int cy, int radius) {
    for (int y = -radius; y <= radius; y++) {
        for (int x = -radius; x <= radius; x++) {
            if (x*x + y*y <= radius*radius) {
                SDL_RenderDrawPoint(renderer, cx + x, cy + y);
            }
        }
    }
}

int main(int argc, char *argv[])
{
    unsigned char done = 0;
    SDL_Rect fillRect;
    //int delay               = 200;
    int delay               = 2;
    SDL_Window* window      = NULL;
    SDL_Renderer* renderer  = NULL;
    SDL_Event e;

    if (SDL_Init(SDL_INIT_VIDEO) != 0)
    {
        printf("SDL No se ha podido inicializar! SDL_Error: %s\n", SDL_GetError());
        return 1;
    }

    //Create window
    window = SDL_CreateWindow("Snake",
                                SDL_WINDOWPOS_UNDEFINED,
                                SDL_WINDOWPOS_UNDEFINED,
                                SCREEN_ORDER,
                                SCREEN_ORDER,
                                SDL_WINDOW_SHOWN);

    if (!window) {
        SDL_Log("Error en la creacion de la ventana: %s\n", SDL_GetError());
        SDL_Quit();
        return -1;
    }



    // Creamos el lienzo
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        SDL_Log("No se ha podido crear el lienzo! SDL Error: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return -1;
    }
    SDL_Texture *imgSnakeHead = loadTexture(IMG_HEAD, renderer);
    if (!imgSnakeHead) {
        printf("Error al cargar el sprite.\n");
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_Quit();
        return -1;
    }


    SDL_SetWindowTitle(window, "Snake template");
    while (!done){ //Se puede parar tambien cuando no se observen cambios!
        while (SDL_PollEvent(&e) != 0) {
            // Salida del usuario
            if (e.type == SDL_QUIT) {
                puts("Saliendo");
                done = 1;
            }else if(e.type == SDL_KEYDOWN){
                //Salida por ESC
                if(e.key.keysym.sym==SDLK_ESCAPE){
                    done = 1;
                };
            }
        }
        //Limpiar pantalla de algun color,
        SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0x00, 0xFF);
        SDL_RenderClear(renderer);

        //Posicion de la figura
        fillRect.x = 50; //Pos X
        fillRect.y = 50; //Pos Y
        //Tam de la figura
        fillRect.h = 30; //Alto
        fillRect.w = 30; //Ancho

        //Pinto un cuadrado de ejemplo
        SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0xFF, 0xFF);
        SDL_RenderFillRect(renderer, &fillRect);

        //Muevo la posicion para que no se superpongan y
        //pinto un ciculo de ejemplo, todo harcodeado, estos numeros
        //tiene que salir de calculos
        fillRect.x = fillRect.x+100; //Pos X
        fillRect.y = fillRect.y+100; //Pos Y
        SDL_SetRenderDrawColor(renderer, 0xFF, 0x00, 0x00, 0xFF);
        drawFilledCircle(renderer, fillRect.x, fillRect.y, 20);

        //Pinto un sprite
        fillRect.x = fillRect.x+100; //Pos X
        fillRect.y = fillRect.y+100; //Pos Y
        SDL_RenderCopy(renderer, imgSnakeHead, NULL, &fillRect);
        SDL_RenderPresent(renderer);
        SDL_Delay(delay);

    }

    //destruyo todos los elementos creados
    //Observar ni mas ni menos que destructores, en la asignatura no inventamos nada!
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}


